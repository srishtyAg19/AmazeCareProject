package com.hexaware.AmazeCare.model;

public enum Role {
	PATIENT,
    DOCTOR,
    ADMIN;

	

}
