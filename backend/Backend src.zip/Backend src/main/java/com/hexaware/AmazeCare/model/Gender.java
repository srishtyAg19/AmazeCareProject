package com.hexaware.AmazeCare.model;

public enum Gender {
	     MALE,
	    FEMALE,
	    OTHER

}
