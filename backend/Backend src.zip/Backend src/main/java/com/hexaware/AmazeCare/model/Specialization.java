package com.hexaware.AmazeCare.model;

public enum Specialization {
	CARDIOLOGY,
    ORTHOPEDICS,
    DERMATOLOGY,
    PEDIATRICS,
    GYNECOLOGY,
    GENERAL_MEDICINE

}
